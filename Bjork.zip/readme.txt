The Bj�rk True Type font: beta version
----------------------------------------------------

* Based on the Debut and Post logos, this font is a work in progress.

* The standard alphabet  (a-z) is available and the character �.

* Numbers and punctuation are on the way as well as more special characters.

* This font is free to everyone. You can redistribute it. Alter it. Print up threatening letters and mail them          
to complete strangers. I don't care. I tried to find this font on the internet without luck on several occasions. 
So, if you like it, spread it around. You could help people like me find more creative ways to waste time. ;-)

* The font is harmless. I am not responsible for any damage you manage to cause installing or using it. 


-- Animus